import "./Footer.css"
import React, { memo } from 'react';

const Footer = memo(() => {
    return <div className="footer">&copy; 2022 All Right Sameh Elsaid</div>;
});

export default Footer;