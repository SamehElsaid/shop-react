import "./Shop.css";
import React, { memo, useState, useEffect, useRef } from "react";
import { CiSearch } from "react-icons/ci";
import { useSelector } from "react-redux";
import Products from "../../Component/Products/Products";
import { motion,AnimatePresence } from "framer-motion";
const Shop = memo(() => {
  const [prodictsData, setProdictsData] = useState(false);
  const all = useSelector((ele) => ele.prodictsData.all);
  const productShow = useRef();
  const view = useRef();
  useEffect(() => {
    all && setProdictsData(all);
    if (view.current.value === "descend") {
      if (productShow.current.value === "Filter By Category") {
        let x = [...all].reverse();
        setProdictsData(x);
      } else {
        let x = all.filter((ele) => ele.category === productShow.current.value);
        let xs = [...x].reverse();
        setProdictsData(xs);
      }
    } else if (view.current.value === "ascending") {
      if (productShow.current.value === "Filter By Category") {
        setProdictsData(all);
      } else {
        let x = all.filter((ele) => ele.category === productShow.current.value);
        setProdictsData(x);
      }
    }
  }, [all]);
  const hadleView = (e) => {
    view.current.value = "ascending";
    if (e.target.value === "Filter By Category") {
      setProdictsData(all);
    } else {
      let x = all.filter((ele) => ele.category === e.target.value);
      setProdictsData(x);
    }
  };
  const hadlenNumbrt = (e) => {
    if (e.target.value === "descend") {
      if (productShow.current.value === "Filter By Category") {
        let x = [...all].reverse();
        setProdictsData(x);
      } else {
        let x = all.filter((ele) => ele.category === productShow.current.value);
        let xs = [...x].reverse();
        setProdictsData(xs);
      }
    } else if (e.target.value === "ascending") {
      if (productShow.current.value === "Filter By Category") {
        setProdictsData(all);
      } else {
        let x = all.filter((ele) => ele.category === productShow.current.value);
        setProdictsData(x);
      }
    }
  };
  const searchProd = (e) => {
    if (productShow.current.value === "Filter By Category") {
      const searchProduct = all.filter((ele) =>
        ele.productName.toLowerCase().includes(e.target.value.toLowerCase())
      );
      setProdictsData(searchProduct);
    } else {
      let x = all.filter((ele) => ele.category === productShow.current.value);
      const searchProduct = x.filter((ele) =>
        ele.productName.toLowerCase().includes(e.target.value.toLowerCase())
      );
      setProdictsData(searchProduct);
    }
  };
  return (
    <div className="shop">
      <div className="mainProducts">
        <h2>Products</h2>
      </div>
      <section className="container">
        <div className="row">
          <div className="col-3">
            <select onChange={hadleView} ref={productShow}>
              <option>Filter By Category</option>
              <option value="chair">Chair</option>
              <option value="sofa">Sofa</option>
              <option value="mobile">Mobile</option>
              <option value="wireless">Wireless</option>
              <option value="watch">Watch</option>
            </select>
          </div>
          <div className="col-3">
            <select
              onChange={hadlenNumbrt}
              ref={view}
              defaultChecked={"ascending"}
            >
              <option disabled>Sort By</option>
              <option value="ascending">Ascending</option>
              <option value="descend">Descend</option>
            </select>
          </div>
          <div className="col-6">
            <form
              className="searchInput"
              onSubmit={(e) => {
                e.preventDefault();
              }}
            >
              <input
                type="text"
                placeholder="Search....."
                defaultValue=""
                onChange={searchProd}
              />
              <CiSearch />
            </form>
          </div>
        </div>
      </section>
      <section className="container pt-0">
        <motion.div layout  className="row">
          <AnimatePresence>

          {prodictsData === false ? (
            "sdsad"
          ) : prodictsData.length > 0 ? (
            prodictsData.map((ele) => (
              <div key={ele.id} className="col-3">
                <Products data={ele} />
              </div>
            ))
          ) : (
            <h2 className="text-center fs-1">No Products Are Found.</h2>
          )}
          </AnimatePresence>
        </motion.div>
      </section>
    </div>
  );
});

export default Shop;
