import React, { memo } from 'react';

const OrderHistory = memo(() => {
    return <div>OrderHistory</div>;
});

export default OrderHistory;