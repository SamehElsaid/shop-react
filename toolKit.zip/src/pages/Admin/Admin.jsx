import React, { memo } from 'react';

const Admin = memo(() => {
    return <div>Admin</div>;
});

export default Admin;