import React, { memo } from 'react';

const Contact = memo(() => {
    return <div>Contact</div>;
});

export default Contact;